# EAGLE YT VERIFY

Python Discord bot for automated screenshot-based YouTube subscription verification.

## Important limitation
This bot checks screenshot text using OCR. It does **not** prove a member currently subscribes to the YouTube channel. Screenshots can be edited or reused. Automatic role assignment is based on visual text heuristics, so false positives and false negatives are possible. Do not treat this as authoritative subscription verification.

## Features
- Slash commands
- YouTube channel URL and expected channel-name configuration
- Verification panel with persistent button
- Screenshot submission through `/submitproof`
- OCR checks for channel name and visible "Subscribed"/"Unsubscribe" text
- Automatic accept/reject, duplicate SHA-256 detection
- Five attempts per member
- SQLite persistent records
- Automatic role assignment after a visual check passes
- Optional result log channel

## Hosting requirements
- Python 3.10+
- Discord bot token
- Discord bot permissions: View Channels, Send Messages, Embed Links, Use Application Commands, Manage Roles
- The bot's highest role must be above the verified role.
- Tesseract OCR system binary must be installed and available on PATH. Installing `pytesseract` alone is not enough.

If your hosting panel supports apt packages, install Tesseract (package commonly named `tesseract-ocr`). If you cannot install the Tesseract system binary, OCR checks will fail closed and submissions will be rejected.

## Setup on bot-hosting.net
1. Upload/extract this ZIP to your Python bot server.
2. Install dependencies from `requirements.txt`.
3. Install the Tesseract OCR system package if the host supports it.
4. In the hosting environment variables, add `DISCORD_TOKEN` with your bot token. Never share the token or put it in public source code.
5. Enable the bot in the Discord Developer Portal and invite it with the `bot` and `applications.commands` scopes. Grant Manage Roles and place its role above the role it should assign.
6. Start with `python main.py`.
7. In Discord, run:
   `/setupverify youtube_url:https://www.youtube.com/@YourChannel channel_name:"Your Channel Name" verified_role:@Verified verify_channel:#verify log_channel:#verification-logs`
8. Run `/postverify` to publish the panel.
9. Members click **Submit Screenshot**, then run `/submitproof` and attach a screenshot.
10. `/verifyinfo` shows attempt count and latest result.

## Data
SQLite database file `verification.sqlite3` is created at runtime. Keep the file on persistent storage if you want records to survive restarts. Back it up periodically.

## Commands
- `/setupverify` — configure channel, role, panel channel, optional log channel (administrator only)
- `/postverify` — post panel (administrator only)
- `/submitproof screenshot:<image>` — submit screenshot
- `/verifyinfo` — show status/attempts
- `/verifyhelp` — help

## Auto decision logic
- Reject unsupported image types, duplicate image bytes, tiny images, missing channel name, unreadable text, or screenshots that show "Subscribe" without a recognized subscribed-state signal.
- Visually approve if the configured channel name is detected and OCR finds "Subscribed" or "Unsubscribe".
- This is intentionally a basic heuristic, not an anti-fraud system. It can be fooled by edited images and can misread YouTube UI variations.
