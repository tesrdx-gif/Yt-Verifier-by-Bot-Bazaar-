import os
import re
import io
import hashlib
import sqlite3
import logging
from datetime import datetime, timezone
from urllib.parse import urlparse

import discord
from discord import app_commands
from discord.ext import commands
from PIL import Image, UnidentifiedImageError

try:
    import pytesseract
    OCR_AVAILABLE = True
except Exception:
    OCR_AVAILABLE = False

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("eagle-yt-verify")

TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
DB_PATH = os.getenv("DATABASE_PATH", "verification.sqlite3")
MAX_ATTEMPTS = 5
MAX_IMAGE_BYTES = 8 * 1024 * 1024
# OCR is only a visual heuristic; it cannot prove a live YouTube subscription.
SUBSCRIBED_TERMS = ("subscribed", "unsubscribe")
NOT_SUBSCRIBED_TERMS = ("subscribe", "join")
YOUTUBE_HOSTS = ("youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be")

intents = discord.Intents.default()
intents.guilds = True
intents.members = True
intents.message_content = False

bot = commands.Bot(command_prefix="!", intents=intents)
db = sqlite3.connect(DB_PATH)
db.row_factory = sqlite3.Row
db.execute("""
CREATE TABLE IF NOT EXISTS guild_config (
 guild_id INTEGER PRIMARY KEY,
 youtube_url TEXT NOT NULL,
 channel_name TEXT NOT NULL,
 verify_channel_id INTEGER NOT NULL,
 verified_role_id INTEGER NOT NULL,
 log_channel_id INTEGER
)
""")
db.execute("""
CREATE TABLE IF NOT EXISTS submissions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 guild_id INTEGER NOT NULL,
 user_id INTEGER NOT NULL,
 image_hash TEXT NOT NULL,
 status TEXT NOT NULL,
 reason TEXT NOT NULL,
 submitted_at TEXT NOT NULL
)
""")
db.execute("""
CREATE TABLE IF NOT EXISTS attempts (
 guild_id INTEGER NOT NULL,
 user_id INTEGER NOT NULL,
 count INTEGER NOT NULL DEFAULT 0,
 PRIMARY KEY(guild_id, user_id)
)
""")
db.commit()

def valid_youtube_url(url: str) -> bool:
    try:
        host = (urlparse(url).hostname or "").lower()
        return host in YOUTUBE_HOSTS and urlparse(url).scheme in ("http", "https")
    except Exception:
        return False

def get_config(guild_id: int):
    return db.execute("SELECT * FROM guild_config WHERE guild_id=?", (guild_id,)).fetchone()

def increment_attempt(guild_id: int, user_id: int) -> int:
    db.execute(
        "INSERT INTO attempts(guild_id,user_id,count) VALUES(?,?,1) "
        "ON CONFLICT(guild_id,user_id) DO UPDATE SET count=count+1",
        (guild_id, user_id)
    )
    db.commit()
    return db.execute(
        "SELECT count FROM attempts WHERE guild_id=? AND user_id=?",
        (guild_id, user_id)
    ).fetchone()["count"]

def attempts_used(guild_id: int, user_id: int) -> int:
    row = db.execute("SELECT count FROM attempts WHERE guild_id=? AND user_id=?",
                     (guild_id, user_id)).fetchone()
    return row["count"] if row else 0

def ocr_review(image_bytes: bytes, expected_channel: str):
    """Returns (approved, reason, OCR text). This is heuristic, not authoritative."""
    if not OCR_AVAILABLE:
        return False, "Automatic image text recognition is unavailable on this host. Install Tesseract OCR and pytesseract, then restart.", ""
    try:
        image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        if image.width < 250 or image.height < 150:
            return False, "Image is too small to review. Upload a clearer screenshot.", ""
        text = pytesseract.image_to_string(image, timeout=12)
        normalized = re.sub(r"\s+", " ", text).strip().lower()
        if not normalized:
            return False, "No readable text was detected. Upload a clear screenshot of the YouTube channel page.", ""
        channel = expected_channel.strip().lower()
        if channel and channel not in normalized:
            return False, f"The screenshot did not visibly show the configured channel name: “{expected_channel}”.", text
        # "Unsubscribe" is a useful visible signal that the account is subscribed.
        if "unsubscribe" in normalized or "subscribed" in normalized:
            return True, "The screenshot contains the channel name and a visible subscribed-state text signal.", text
        if "subscribe" in normalized:
            return False, "The screenshot appears to show “Subscribe”, not a subscribed state. Subscribe first, then upload a fresh screenshot.", text
        return False, "Could not find a clear “Subscribed” state. Upload a screenshot showing the channel name and subscribed button.", text
    except Exception as exc:
        log.warning("OCR failed: %s", exc)
        return False, "The image could not be reviewed automatically. Try a PNG/JPG screenshot with readable text.", ""

async def safe_log(guild: discord.Guild, config, message: str):
    channel_id = config["log_channel_id"] if config else None
    if channel_id:
        channel = guild.get_channel(channel_id)
        if channel and hasattr(channel, "send"):
            try:
                await channel.send(message)
            except discord.HTTPException:
                pass

class VerifyView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Submit Screenshot", style=discord.ButtonStyle.primary,
                       emoji="📸", custom_id="eagle_yt_verify:submit")
    async def submit(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.guild:
            return await interaction.response.send_message("Use this button inside your server.", ephemeral=True)
        config = get_config(interaction.guild.id)
        if not config:
            return await interaction.response.send_message("Verification is not configured yet. Ask an administrator to run `/setupverify`.", ephemeral=True)
        if attempts_used(interaction.guild.id, interaction.user.id) >= MAX_ATTEMPTS:
            return await interaction.response.send_message(
                f"You have used all {MAX_ATTEMPTS} screenshot attempts. Contact a server administrator if you believe this is an error.",
                ephemeral=True
            )
        return await interaction.response.send_message(
            f"Submit your screenshot with `/submitproof` in this server.\n"
            f"**YouTube channel:** {config['youtube_url']}\n"
            f"**Attempts remaining:** {MAX_ATTEMPTS - attempts_used(interaction.guild.id, interaction.user.id)}\n\n"
            "The bot checks visible text in the image. A screenshot is not conclusive proof of a live subscription.",
            ephemeral=True
        )

@bot.event
async def on_ready():
    bot.add_view(VerifyView())
    try:
        synced = await bot.tree.sync()
        log.info("Synced %d application commands", len(synced))
    except Exception:
        log.exception("Command sync failed")
    log.info("Logged in as %s (%s)", bot.user, bot.user.id if bot.user else "?")

@bot.tree.command(name="setupverify", description="Configure YouTube screenshot verification")
@app_commands.checks.has_permissions(administrator=True)
@app_commands.describe(
    youtube_url="Your YouTube channel URL",
    channel_name="Exact channel name visible on screenshots",
    verified_role="Role granted after automatic visual checks pass",
    verify_channel="Channel where the verification panel will be posted",
    log_channel="Optional channel for verification results"
)
async def setupverify(interaction: discord.Interaction, youtube_url: str, channel_name: str,
                      verified_role: discord.Role, verify_channel: discord.TextChannel,
                      log_channel: discord.TextChannel | None = None):
    if not interaction.guild:
        return await interaction.response.send_message("Use this command in a server.", ephemeral=True)
    if not valid_youtube_url(youtube_url):
        return await interaction.response.send_message("Please provide a valid YouTube channel URL.", ephemeral=True)
    if verified_role.is_default() or verified_role >= interaction.guild.me.top_role:
        return await interaction.response.send_message(
            "Choose a non-@everyone role that is below the bot's highest role.", ephemeral=True
        )
    db.execute("""
    INSERT INTO guild_config(guild_id,youtube_url,channel_name,verify_channel_id,verified_role_id,log_channel_id)
    VALUES(?,?,?,?,?,?)
    ON CONFLICT(guild_id) DO UPDATE SET youtube_url=excluded.youtube_url,
    channel_name=excluded.channel_name, verify_channel_id=excluded.verify_channel_id,
    verified_role_id=excluded.verified_role_id, log_channel_id=excluded.log_channel_id
    """, (interaction.guild.id, youtube_url, channel_name, verify_channel.id,
          verified_role.id, log_channel.id if log_channel else None))
    db.commit()
    await interaction.response.send_message(
        f"✅ Verification configured.\nChannel: {youtube_url}\nRole: {verified_role.mention}\n"
        f"Panel channel: {verify_channel.mention}\nOCR available: **{OCR_AVAILABLE}**\n"
        "Note: screenshot checks are heuristic and do not prove a live subscription.",
        ephemeral=True
    )

@bot.tree.command(name="postverify", description="Post the YouTube verification panel")
@app_commands.checks.has_permissions(administrator=True)
async def postverify(interaction: discord.Interaction):
    if not interaction.guild:
        return await interaction.response.send_message("Use this command in a server.", ephemeral=True)
    config = get_config(interaction.guild.id)
    if not config:
        return await interaction.response.send_message("Run `/setupverify` first.", ephemeral=True)
    channel = interaction.guild.get_channel(config["verify_channel_id"])
    if not isinstance(channel, discord.TextChannel):
        return await interaction.response.send_message("Configured verification channel was not found.", ephemeral=True)
    embed = discord.Embed(
        title="YouTube Subscription Verification",
        description=(
            f"1. Open [our YouTube channel]({config['youtube_url']}) and subscribe.\n"
            "2. Take a clear screenshot showing the channel name and subscribed state.\n"
            "3. Click **Submit Screenshot**, then use `/submitproof` to upload it.\n\n"
            "The bot uses automatic OCR-based visual checks. Screenshots can be edited and this does **not** prove a live subscription."
        ),
        color=0xFF0033
    )
    embed.set_footer(text=f"EAGLE YT VERIFY • Up to {MAX_ATTEMPTS} attempts")
    await channel.send(embed=embed, view=VerifyView())
    await interaction.response.send_message(f"Verification panel posted in {channel.mention}.", ephemeral=True)

@bot.tree.command(name="submitproof", description="Submit a YouTube subscription screenshot")
@app_commands.describe(screenshot="Clear PNG/JPG screenshot showing the channel name and subscribed state")
async def submitproof(interaction: discord.Interaction, screenshot: discord.Attachment):
    if not interaction.guild:
        return await interaction.response.send_message("Use this command inside your server.", ephemeral=True)
    guild = interaction.guild
    config = get_config(guild.id)
    if not config:
        return await interaction.response.send_message("Verification is not configured. Ask an administrator to run `/setupverify`.", ephemeral=True)
    member = guild.get_member(interaction.user.id)
    role = guild.get_role(config["verified_role_id"])
    if member and role and role in member.roles:
        return await interaction.response.send_message("You already have the verified role.", ephemeral=True)
    used = attempts_used(guild.id, interaction.user.id)
    if used >= MAX_ATTEMPTS:
        return await interaction.response.send_message(f"You have reached the {MAX_ATTEMPTS}-attempt limit.", ephemeral=True)
    if screenshot.size > MAX_IMAGE_BYTES:
        return await interaction.response.send_message("Image is too large. Maximum size is 8 MB.", ephemeral=True)
    if screenshot.content_type and not screenshot.content_type.startswith("image/"):
        return await interaction.response.send_message("Please upload an image file.", ephemeral=True)
    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        raw = await screenshot.read()
        image = Image.open(io.BytesIO(raw))
        if image.format not in ("PNG", "JPEG", "WEBP"):
            raise UnidentifiedImageError("unsupported")
        image_hash = hashlib.sha256(raw).hexdigest()
    except Exception:
        return await interaction.followup.send("Rejected: that file is not a supported PNG, JPG, or WEBP image.", ephemeral=True)

    duplicate = db.execute("SELECT user_id FROM submissions WHERE guild_id=? AND image_hash=?",
                           (guild.id, image_hash)).fetchone()
    if duplicate:
        # Count duplicate attempts too, so repeated uploads cannot bypass the limit.
        count = increment_attempt(guild.id, interaction.user.id)
        reason = "This exact image has already been submitted. Upload a new, genuine screenshot."
        db.execute("INSERT INTO submissions(guild_id,user_id,image_hash,status,reason,submitted_at) VALUES(?,?,?,?,?,?)",
                   (guild.id, interaction.user.id, image_hash, "rejected", reason, datetime.now(timezone.utc).isoformat()))
        db.commit()
        await interaction.followup.send(f"❌ **Rejected:** {reason}\nAttempts used: {count}/{MAX_ATTEMPTS}.", ephemeral=True)
        await safe_log(guild, config, f"❌ Duplicate screenshot rejected for {interaction.user.mention} (`{interaction.user.id}`).")
        return

    count = increment_attempt(guild.id, interaction.user.id)
    approved, reason, ocr_text = ocr_review(raw, config["channel_name"])
    # If OCR is unavailable or uncertain, reject rather than granting access blindly.
    status = "approved_visual_check" if approved else "rejected"
    db.execute("INSERT INTO submissions(guild_id,user_id,image_hash,status,reason,submitted_at) VALUES(?,?,?,?,?,?)",
               (guild.id, interaction.user.id, image_hash, status, reason, datetime.now(timezone.utc).isoformat()))
    db.commit()

    if approved:
        if not member:
            member = await guild.fetch_member(interaction.user.id)
        if not role:
            await interaction.followup.send("The configured role no longer exists. Ask an administrator to rerun `/setupverify`.", ephemeral=True)
            return
        try:
            await member.add_roles(role, reason="EAGLE YT VERIFY: screenshot passed automated visual checks")
        except discord.Forbidden:
            await interaction.followup.send("I cannot assign the role. Move my bot role above the verified role and check Manage Roles permission.", ephemeral=True)
            return
        await interaction.followup.send(
            f"✅ **Visual check passed!** {role.mention} has been assigned.\n"
            f"Reason: {reason}\n"
            "⚠️ This means the screenshot passed text checks; it does not prove your live YouTube subscription.",
            ephemeral=True
        )
        await safe_log(guild, config, f"✅ Visual check passed for {interaction.user.mention}; role assigned. This is not authoritative subscription proof.")
    else:
        await interaction.followup.send(
            f"❌ **Rejected:** {reason}\nAttempts used: {count}/{MAX_ATTEMPTS}.\n"
            + (f"Attempts remaining: {MAX_ATTEMPTS-count}." if count < MAX_ATTEMPTS else "No attempts remain; contact an administrator if this is a mistake."),
            ephemeral=True
        )
        await safe_log(guild, config, f"❌ Screenshot rejected for {interaction.user.mention} (`{interaction.user.id}`). Reason: {reason}")

@bot.tree.command(name="verifyinfo", description="Show verification status and remaining attempts")
async def verifyinfo(interaction: discord.Interaction):
    if not interaction.guild:
        return await interaction.response.send_message("Use this in your server.", ephemeral=True)
    config = get_config(interaction.guild.id)
    used = attempts_used(interaction.guild.id, interaction.user.id)
    row = db.execute("SELECT status, reason, submitted_at FROM submissions WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 1",
                     (interaction.guild.id, interaction.user.id)).fetchone()
    msg = f"Attempts used: **{used}/{MAX_ATTEMPTS}**\nAttempts remaining: **{max(0, MAX_ATTEMPTS-used)}**"
    if config:
        msg += f"\nYouTube channel: {config['youtube_url']}"
    if row:
        msg += f"\nLatest result: **{row['status']}**\nReason: {row['reason']}"
    await interaction.response.send_message(msg, ephemeral=True)

@bot.tree.command(name="verifyhelp", description="Show EAGLE YT VERIFY help")
async def verifyhelp(interaction: discord.Interaction):
    await interaction.response.send_message(
        "**EAGLE YT VERIFY**\n"
        "• `/setupverify` — administrator setup\n"
        "• `/postverify` — post the verification panel\n"
        "• `/submitproof` — submit screenshot\n"
        "• `/verifyinfo` — check attempts/status\n"
        "The bot performs OCR-based visual checks only. It cannot guarantee a live YouTube subscription from a screenshot.",
        ephemeral=True
    )

@bot.event
async def on_command_error(ctx, error):
    await ctx.send(f"Command error: {error}")

if not TOKEN:
    raise RuntimeError("Missing DISCORD_TOKEN environment variable. Add it in your hosting panel, not in source code.")

bot.run(TOKEN)
